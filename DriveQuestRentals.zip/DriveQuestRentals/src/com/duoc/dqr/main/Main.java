package com.duoc.dqr.main;

import com.duoc.dqr.FleetManager.Manager;
import com.duoc.dqr.cars.CargoVehicle;
import com.duoc.dqr.cars.PassengersVehicle;
import com.duoc.dqr.cars.Vehicle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Map<String, Vehicle> fleetLicense = new HashMap<>();
        List<Vehicle> fleet = new ArrayList<>();

        Scanner sc = new Scanner(System.in);
        Manager manager = new Manager(fleetLicense, fleet);

        boolean anotherOperation = true;
        int menuOption;

        do {
            while (true) {
                System.out.println("=== DRIVE QUEST RENTALS ===");
                System.out.println("1. Arrendar Vehiculo");
                System.out.println("2. Devolver Vehiculo Arrendado.");
                System.out.println("3. Agregar Vehiculo a la Flota.");
                System.out.println("4. Lista de Arriendos Mayores a 7 Dias.");
                System.out.println("5. Lista de Vehiculos.");
                System.out.println("6. Salir.");
                System.out.print("Eliga una opcion: ");
                System.out.println(" ");

                try {
                    menuOption = sc.nextInt();
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Ingrese una opcion valida del menu.");
                    sc.nextLine();
                }
            }

            sc.nextLine();

            switch (menuOption) {
                case 1: // Arrendar Vehiculo

                    break;

                case 2:  // Devolver Vehiculo Arrendado

                    break;

                case 3: // Agregar Vehiculo a la Flota

                    break;

                case 4: // Lista de Arriendos Mayores a 7 Dias

                    break;

                case 5: // Lista de Vehiculos

                    List<Vehicle> vehicles = manager.listVehicles();
                    for (Vehicle v : vehicles) {
                        System.out.println(v);
                    }

                        break;

                    
                    case 6: // Salir
                    System.out.println("Gracias Por Preferirnos!");
                    anotherOperation = false;
                    break;

                default:
                    System.out.println("Opcion invalida porfavor vuelva a intentarlo.");
                    break;
            }

            if (menuOption != 4) {
                        int continueOption;
                        do {
                            System.out.println("\nLe gustaria hacer otra operacion?");
                            System.out.println("1. Si.");
                            System.out.println("2. No.");

                            try {
                                continueOption = sc.nextInt();
                                if (continueOption == 1) {
                                    anotherOperation = true;
                                } else if (continueOption == 2) {
                                    System.out.println("Gracias Por Preferirnos!");
                                    anotherOperation = false;
                                } else {
                                    System.out.println("Ingrese una opcion valida.");
                                }
                            } catch (InputMismatchException e) {
                                System.out.println("Error, ingrese un numero valido.");
                                sc.nextLine();
                                continueOption = 0;
                            }
                        } while (continueOption != 1 && continueOption != 2);
                    }
            }
            while (anotherOperation);

            sc.close();
        }
    }
//ik
